// Top-level build file where you can add configuration options common to all sub-projects/modules.
@Suppress("DSL_SCOPE_VIOLATION") // TODO: Remove once KTIJ-19369 is fixed
plugins {
    alias(libs.plugins.androidApplication) apply false
    alias(libs.plugins.kotlinAndroid) apply false
    id("com.google.protobuf") version "0.9.3" apply false
}

ext["grpcVersion"] = "1.57.2"
ext["grpcKotlinVersion"] = "1.3.1" // CURRENT_GRPC_KOTLIN_VERSION
ext["protobufVersion"] = "3.24.1"

true // Needed to make the Suppress annotation work for the plugins block
