import org.jetbrains.kotlin.gradle.dsl.kotlinExtension

plugins {
    id("java-library")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
    sourceSets.getByName("main").resources.srcDir("src/main/proto")
}
